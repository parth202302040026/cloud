import UserDetails from "./UserDetails.jsx";
//import AuthForm from "./AuthForm.jsx";


function App() {

    return(
      <>
        <UserDetails />
      </>
    );
  
}

export default App
#!/bin/bash
yum update -y